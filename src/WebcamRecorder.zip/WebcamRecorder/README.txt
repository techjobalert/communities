A chromeless ActionScript 3 Library for video/audio/still image recording from webcams.

Initial code by Alexis Taugeron (@ataugeron).
Patchs by Fran�ois Lagunas (@madlag)

Code is released under a BSD License:
http://www.opensource.org/licenses/bsd-license.php

This library use the JPEG encoder available at https://github.com/mikechambers/as3corelib .



